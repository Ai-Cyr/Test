# Prompts de test

```text
Fais un audit qualité complet de cette table Impala et donne un rapport détaillé.
```

```text
Montre-moi le schéma et signale les colonnes qui semblent critiques pour la qualité.
```

```text
Quel est le taux de null par colonne ? Donne les 10 colonnes les plus problématiques.
```

```text
Vérifie les doublons sur la clé configurée.
```

```text
Combien de lignes contient la table ?
```

```text
Exécute une requête lecture seule pour lister les 20 valeurs les plus fréquentes de la colonne status.
```

```text
Fais un audit qualité complet et affiche les graphiques dans Agent Hub.
```

```text
Génère un graphique du taux de null et un graphique du statut des règles qualité.
```
