"""
Example client for calling a Dataiku LLM Mesh agent through the OpenAI-compatible API
with streaming enabled.

Install locally if you use this script outside DSS:
    pip install openai

Environment variables:
    DKU_BASE_URL   Example: https://dataiku.mycompany.com
    DKU_PROJECT_KEY
    DKU_API_KEY
    DKU_AGENT_ID   Example: agent:xxxxxxxx
"""

from __future__ import annotations

import os
import sys
from openai import OpenAI


def required_env(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing environment variable: {name}")
    return value


def main() -> None:
    dku_base_url = required_env("DKU_BASE_URL").rstrip("/")
    project_key = required_env("DKU_PROJECT_KEY")
    api_key = required_env("DKU_API_KEY")
    agent_id = required_env("DKU_AGENT_ID")
    prompt = " ".join(sys.argv[1:]).strip() or "Fais un audit qualité complet de la table et donne un rapport détaillé."

    client = OpenAI(
        api_key=api_key,
        base_url=f"{dku_base_url}/public/api/projects/{project_key}/llms/openai/v1/",
    )

    stream = client.chat.completions.create(
        model=agent_id,
        messages=[{"role": "user", "content": prompt}],
        stream=True,
    )

    for event in stream:
        if not event.choices:
            continue
        delta = event.choices[0].delta
        if delta and delta.content:
            print(delta.content, end="", flush=True)
    print()


if __name__ == "__main__":
    main()
