# Agent Dataiku Data Quality sur Impala avec LangGraph + streaming + SQLExecutor2 uniquement

Ce projet contient un agent Dataiku prêt à adapter pour faire de la data quality sur une table Impala. Il utilise :

- `dataiku.llm.python.BaseLLM` comme classe d’entrée de l’agent Dataiku ;
- `process`, `process_stream` et `aprocess_stream` pour les usages non streamés et streamés ;
- LangGraph pour orchestrer le workflow : planification, lecture du schéma, profiling, contrôles qualité, réponse finale ;
- `dataiku.SQLExecutor2` **uniquement** pour exécuter les requêtes sur le dataset ou la connexion SQL DSS pointant vers Impala ;
- une validation SQL stricte pour limiter les requêtes générées à du lecture seule ;
- un rapport détaillé Markdown incluant synthèse, règles, anomalies, profiling colonne par colonne, audit trail SQL et recommandations ;
- des artefacts Agent Hub `RECORDS` chartables, plus des graphiques PNG optionnels encodés en `DATA_INLINE`.

## Contenu du ZIP

```text
code-agent/dss_code_agent.py
plugin/plugin.json
plugin/code-env/python/spec/requirements.txt
plugin/python-agents/dq_langgraph_sqlexecutor2/agent.py
plugin/python-agents/dq_langgraph_sqlexecutor2/agent.json
requirements.txt
scripts/stream_agent_from_outside.py
examples/sample_prompts.md
tests/test_sql_safety.py
tests/test_agent_hub_artifacts_static.py
```

## Option A — Utilisation comme Code Agent Dataiku

1. Créez ou sélectionnez un code env Python 3.10+.
2. Installez les dépendances de `requirements.txt` dans ce code env.
3. Dans le Flow Dataiku, créez un **Code Agent**.
4. Collez le contenu de `code-agent/dss_code_agent.py` dans l’onglet **Code**.
5. Dans l’onglet **Settings**, sélectionnez le code env.
6. Renseignez les constantes en haut du fichier :

```python
LLM_ID = "openai:my-openai-connection:gpt-4o-mini"
DATASET_NAME = "mon_dataset_impala"
PRIMARY_KEY_COLUMNS = ["id"]
REQUIRED_COLUMNS = ["id", "event_date"]
DATE_COLUMNS = ["event_date"]
```

Le mode recommandé est `DATASET_NAME`, avec un dataset Dataiku déjà adossé à Impala. L’agent instancie alors :

```python
SQLExecutor2(dataset=dataiku.Dataset(DATASET_NAME))
```

## Option B — Utilisation avec une connexion SQL DSS vers Impala

Si vous ne voulez pas passer par un dataset Dataiku, configurez une connexion DSS SQL pointant vers Impala :

```python
SQL_CONNECTION = "ma_connexion_impala_dss"
SQL_DATABASE = "ma_base"      # optionnel
SQL_TABLE = "ma_table"        # obligatoire sans DATASET_NAME
```

L’agent instancie alors uniquement :

```python
SQLExecutor2(connection=SQL_CONNECTION)
```

`SQL_DATABASE` n’est pas transmis au constructeur `SQLExecutor2`; il sert seulement à construire la référence SQL `` `database`.`table` ``.

## Option C — Utilisation comme Custom Agent plugin Dataiku

Le dossier `plugin/` contient une structure de plugin minimaliste.

1. Créez un plugin Dataiku ou importez le dossier `plugin/`.
2. Construisez le code env du plugin avec `plugin/code-env/python/spec/requirements.txt`.
3. Le composant Custom Agent se trouve dans :

```text
plugin/python-agents/dq_langgraph_sqlexecutor2/
```

4. Configurez les paramètres dans l’UI : `llm_id`, puis `dataset_name` ou `sql_connection` + `sql_table`, puis les seuils qualité.

## Configuration possible par variables de projet

Vous pouvez aussi définir des variables Dataiku avec le préfixe `DQ_AGENT_` :

```text
DQ_AGENT_LLM_ID=openai:my-openai-connection:gpt-4o-mini
DQ_AGENT_DATASET_NAME=mon_dataset_impala
DQ_AGENT_SQL_CONNECTION=ma_connexion_impala_dss
DQ_AGENT_SQL_DATABASE=ma_base
DQ_AGENT_SQL_TABLE=ma_table
DQ_AGENT_PRIMARY_KEY_COLUMNS=id,event_date
DQ_AGENT_REQUIRED_COLUMNS=id,event_date,amount
DQ_AGENT_DATE_COLUMNS=event_date
DQ_AGENT_MAX_NULL_RATE=0.10
DQ_AGENT_MAX_EMPTY_RATE=0.02
DQ_AGENT_MAX_DUPLICATE_RATE=0
DQ_AGENT_MAX_DATA_AGE_DAYS=2
DQ_AGENT_MAX_PROFILE_COLUMNS=80
DQ_AGENT_MAX_REPORT_COLUMNS=80
DQ_AGENT_MAX_CHART_ROWS=30
DQ_AGENT_ENABLE_AGENT_HUB_ARTIFACTS=true
DQ_AGENT_ENABLE_PNG_CHARTS=true
DQ_AGENT_REVEAL_SQL=true
DQ_AGENT_USE_LLM_FINAL_SUMMARY=true
```

Priorité de configuration : constantes du code < variables projet `DQ_AGENT_*` < config plugin `agent.json`.

Les anciens noms `DQ_AGENT_IMPALA_CONNECTION`, `DQ_AGENT_IMPALA_DATABASE` et `DQ_AGENT_IMPALA_TABLE` sont acceptés comme alias de compatibilité, mais le code utilise toujours `SQLExecutor2` uniquement.

## Contrôles qualité inclus

L’agent calcule automatiquement :

- nombre de lignes ;
- taux de `NULL` par colonne ;
- `NDV()` Impala comme nombre approximatif de valeurs distinctes ;
- chaînes vides et longueurs min/max sur colonnes texte ;
- min/max/avg sur colonnes numériques ;
- min/max sur colonnes date/timestamp ;
- doublons et clés nulles si `PRIMARY_KEY_COLUMNS` est renseigné ;
- présence des colonnes obligatoires si `REQUIRED_COLUMNS` est renseigné ;
- fraîcheur des données si `DATE_COLUMNS` et `max_data_age_days` sont renseignés.

## Rapport détaillé produit

Pour un audit qualité complet, la réponse finale est un rapport Markdown avec :

1. synthèse exécutive, statut global et score indicatif ;
2. périmètre, table, connexion et seuils ;
3. résultat détaillé de toutes les règles qualité ;
4. anomalies et points d’attention ;
5. contrôle de clé / unicité ;
6. profiling détaillé par colonne ;
7. recommandations correctives ;
8. audit trail SQL des requêtes exécutées ;
9. données techniques synthétiques.

La synthèse indique aussi que des artefacts `RECORDS` sont générés pour l’Agent Hub : KPI qualité, statut des règles, taux de NULL, chaînes vides, cardinalité approximative et résumé des doublons si une clé est configurée.

Si `use_llm_final_summary=true`, le LLM ajoute une courte lecture experte au rapport, sans remplacer les sections déterministes.


## Graphiques dans Agent Hub

L’agent retourne les graphiques sous forme d’artefacts Dataiku :

- `RECORDS` : format principal, utilisé par Agent Hub pour générer des graphiques dans le chat. Chaque artefact contient `records.columns` et `records.data` avec une table courte et chartable.
- `DATA_INLINE` `image/png` : rendu PNG optionnel créé avec `matplotlib` et renvoyé comme artefact image. Cette option est utile quand l’interface prévisualise les images, et reste désactivable.
- `GENERATED_SQL_QUERY` : audit de la requête exécutée quand `reveal_sql=true`.

Paramètres associés :

```text
DQ_AGENT_ENABLE_AGENT_HUB_ARTIFACTS=true   # génère les artefacts RECORDS
DQ_AGENT_ENABLE_PNG_CHARTS=true            # ajoute les images PNG
DQ_AGENT_MAX_CHART_ROWS=30                 # limite les lignes/colonnes exposées par graphique
```

Dans un Custom Agent plugin, les mêmes paramètres sont disponibles dans l’UI : `enable_agent_hub_artifacts`, `enable_png_charts` et `max_chart_rows`.

## Streaming

L’agent implémente :

```python
async def aprocess_stream(self, query, settings, trace):
    ...
    yield {"chunk": {"text": "..."}}
```

Il streame trois types d’informations :

1. des événements de progression Dataiku, par exemple `Lecture du schéma via SQLExecutor2` ;
2. les tokens de la réponse finale si le modèle LLM Mesh les expose via LangGraph ; sinon il streame le rapport final en petits chunks Markdown ;
3. les artefacts `RECORDS` / `DATA_INLINE` à la fin du flux via `yield {"chunk": {"artifacts": [...]}}`.

## Sécurité SQL

Les requêtes SQL générées par le LLM passent par `ensure_read_only_sql()` :

- autorisé : `SELECT`, `WITH`, `SHOW`, `DESCRIBE`, `DESC` ;
- interdit : `INSERT`, `UPDATE`, `DELETE`, `CREATE`, `DROP`, `ALTER`, `REFRESH`, `INVALIDATE`, `COMPUTE STATS`, `SET`, `USE`, etc. ;
- une seule instruction est autorisée ;
- un `LIMIT` est ajouté automatiquement aux requêtes `SELECT/WITH` si absent.

Les requêtes de profiling générées par le code sont déterministes et ne viennent pas directement du LLM.

## Exemples de prompts

```text
Fais un audit qualité complet de la table et donne un rapport détaillé.
Montre le schéma et les types de colonnes.
Quel est le taux de null par colonne ?
Vérifie les doublons sur la clé configurée.
Combien de lignes contient la table ?
Liste les 20 valeurs les plus fréquentes de status.
```

## Notes d’adaptation

- Adaptez les seuils selon votre contexte métier.
- Limitez `MAX_PROFILE_COLUMNS` si la table est très large.
- Ajustez `MAX_REPORT_COLUMNS` si le rapport devient trop long.
- Ajustez `MAX_CHART_ROWS` si les graphiques Agent Hub affichent trop de catégories.
- Désactivez `ENABLE_PNG_CHARTS` si vous voulez seulement des graphiques natifs Agent Hub basés sur les artefacts `RECORDS`.
- Pour de très grosses tables, envisagez une version échantillonnée ou partitionnée des requêtes de profiling.
- Si votre dataset Dataiku n’expose pas le bon nom de table physique, utilisez `SQL_CONNECTION`, `SQL_DATABASE` et `SQL_TABLE`.
