"""Static checks proving the package is configured for SQLExecutor2 only."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_agent_uses_sqlexecutor2_only():
    code = (ROOT / "code-agent" / "dss_code_agent.py").read_text(encoding="utf-8")
    assert "from dataiku import SQLExecutor2" in code
    assert "Impala" + "Executor" not in code
    assert "Hive" + "Executor" not in code
    assert "use_impala" + "_executor" not in code


def test_report_sections_present():
    code = (ROOT / "code-agent" / "dss_code_agent.py").read_text(encoding="utf-8")
    for section in [
        "# Rapport détaillé de data quality",
        "## 3. Résultat détaillé des règles",
        "## 6. Profiling détaillé par colonne",
        "## 8. Audit trail SQL",
        "dataiku.SQLExecutor2",
    ]:
        assert section in code
