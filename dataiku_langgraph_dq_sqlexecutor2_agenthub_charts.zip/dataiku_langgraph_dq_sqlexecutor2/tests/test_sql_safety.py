"""Minimal local tests for SQL safety helpers.

These tests duplicate the safety helpers so they can run outside Dataiku without importing
`dataiku`. They are provided as a reference for your own test suite.
"""

from __future__ import annotations

import re

FORBIDDEN_SQL_WORDS = {
    "alter", "analyze", "compute", "create", "delete", "drop", "grant", "insert",
    "invalidate", "load", "merge", "msck", "refresh", "rename", "replace", "revoke",
    "set", "truncate", "update", "upsert", "use",
}
ALLOWED_FIRST_TOKENS = {"select", "with", "show", "describe", "desc"}


class UnsafeSQLError(ValueError):
    pass


def sql_strip_markdown(sql: str) -> str:
    sql = str(sql or "").strip()
    sql = re.sub(r"^```(?:sql)?\s*", "", sql, flags=re.IGNORECASE)
    sql = re.sub(r"\s*```$", "", sql)
    return sql.strip()


def remove_sql_comments(sql: str) -> str:
    sql = re.sub(r"--.*?$", "", sql, flags=re.MULTILINE)
    sql = re.sub(r"/\*.*?\*/", "", sql, flags=re.DOTALL)
    return sql


def ensure_read_only_sql(sql: str) -> str:
    cleaned = remove_sql_comments(sql_strip_markdown(sql)).strip()
    cleaned = cleaned.rstrip(";").strip()
    if not cleaned:
        raise UnsafeSQLError("empty")
    if ";" in cleaned:
        raise UnsafeSQLError("multiple statements")
    first_match = re.match(r"^\s*([A-Za-z]+)", cleaned)
    first = first_match.group(1).lower() if first_match else ""
    if first not in ALLOWED_FIRST_TOKENS:
        raise UnsafeSQLError("not read only")
    lower = cleaned.lower()
    for word in FORBIDDEN_SQL_WORDS:
        if re.search(rf"\b{re.escape(word)}\b", lower):
            raise UnsafeSQLError(word)
    return cleaned


def add_limit_if_needed(sql: str, max_rows: int) -> str:
    cleaned = ensure_read_only_sql(sql)
    first = re.match(r"^\s*([A-Za-z]+)", cleaned).group(1).lower()
    if first not in {"select", "with"}:
        return cleaned
    if re.search(r"\blimit\s+\d+\s*$", cleaned, flags=re.IGNORECASE):
        return cleaned
    return f"{cleaned}\nLIMIT {int(max_rows)}"


def test_select_allowed_and_limited():
    assert add_limit_if_needed("select * from my_table", 10).endswith("LIMIT 10")


def test_describe_allowed_without_limit():
    assert add_limit_if_needed("describe my_table", 10).lower().startswith("describe")


def test_delete_rejected():
    try:
        ensure_read_only_sql("delete from my_table")
    except UnsafeSQLError:
        return
    raise AssertionError("DELETE should be rejected")


def test_multiple_statements_rejected():
    try:
        ensure_read_only_sql("select * from t; drop table t")
    except UnsafeSQLError:
        return
    raise AssertionError("multiple statements should be rejected")
