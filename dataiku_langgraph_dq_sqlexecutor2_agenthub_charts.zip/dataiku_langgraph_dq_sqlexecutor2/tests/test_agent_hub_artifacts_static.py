"""Static checks for Agent Hub chart artifact support."""

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CODE = (ROOT / "code-agent" / "dss_code_agent.py").read_text(encoding="utf-8")
AGENT_JSON = (ROOT / "plugin" / "python-agents" / "dq_langgraph_sqlexecutor2" / "agent.json").read_text(encoding="utf-8")
REQS = (ROOT / "requirements.txt").read_text(encoding="utf-8")


def test_records_artifacts_are_returned_for_agent_hub_charts():
    assert "def make_records_artifact" in CODE
    assert '"type": "RECORDS"' in CODE
    assert '"records": records' in CODE
    assert '"chunk": {"artifacts": final_artifacts}' in CODE
    assert '"artifacts": result.get("artifacts", [])' in CODE


def test_png_artifacts_are_optional_and_declared():
    assert "ENABLE_PNG_CHARTS" in CODE
    assert '"mimeType": mime_type' in CODE
    assert '"dataBase64": data_base64' in CODE
    assert "matplotlib" in REQS


def test_plugin_exposes_chart_parameters():
    for name in ["enable_agent_hub_artifacts", "enable_png_charts", "max_chart_rows"]:
        assert name in AGENT_JSON
