# -*- coding: utf-8 -*-
"""
Agent Dataiku + LangGraph pour Text-to-SQL Impala avec Mistral Small 3.2
========================================================================

Architecture :

    START
      -> initial_think
          -> direct_response si la réponse est évidente
          -> sinon context_start
                -> search_portfolio en parallèle si besoin
                -> get_filter en parallèle si besoin
                -> get_date en parallèle si besoin
          -> plan
          -> generate_sql
          -> execute_sql
          -> judge_result
                -> generate_sql si correction nécessaire
                -> formulate_answer si résultat suffisant ou limite atteinte
      -> END

Principe important :
- Pas de tool-calling LangChain/Mistral pour l'exécution SQL.
- Les étapes sont des noeuds LangGraph explicites.
- Le LLM produit du JSON, un plan, du SQL, puis une reformulation.
- Cela évite les erreurs Mistral liées aux messages assistant avec tool_calls.

A adapter dans chaque projet :
- LLM_ID
- SQL_CONNECTION
- TABLE_NAME
- éventuelles règles métier dans SCHEMA_DESCRIPTION
"""

from __future__ import annotations

import json
import re
from datetime import date
from operator import add as list_add
from typing import Annotated, Any, TypedDict

import dataiku
from dataiku import SQLExecutor2
from dataiku.llm.python import BaseLLM

from langchain_core.messages import AIMessage, AnyMessage, HumanMessage, SystemMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages

# =============================================================================
# CONFIGURATION PROJET
# =============================================================================

# Mistral Small 3.2 = release 2506.
# Le nom exact dépend de la connexion LLM Mesh déclarée chez vous.
LLM_ID = "mistral:votre-connexion:mistral-small-2506"

SQL_CONNECTION = "votre_connexion_sql"

# Nom de la table Impala à interroger.
# Exemple possible : "db_risque.ma_table_valorisation"
TABLE_NAME = "votre_table_impala"

MAX_ROWS = 50
MAX_SQL_ATTEMPTS = 3
TEMPERATURE = 0.15

# En streaming, affiche des messages d'avancement par noeud.
STREAM_PROGRESS = True

# =============================================================================
# DESCRIPTION DU SCHEMA
# =============================================================================

PORTFOLIO_COLUMNS = [
    "id_portefeuille",
    "classification_portefeuille_l7",
    "type_ptf_cpt_french_l6",
    "code_niveau_6",
    "code_niveau_7",
]

DATE_COLUMNS = [
    "date_valorisation",
    "date_insertion",
]

FILTERABLE_COLUMNS = [
    "id_valeur",
    "id_contrat_mx",
    "libelle_famille_valeur",
    "code_tiers_emetteur",
    "emetteur",
    "code_direction",
    "secteur_eco_2_lib",
    "libelle_famille",
    "secteur_eco_icb_n3_libelle",
    "secteur_eco_bic3_n3_libelle",
    "devise_engagement",
    "cod_pays_implant",
    "relation_couverture",
    "type_risques_l4",
    "source",
    "reference_grappage",
    "num_lot",
    "id_valeur_sous_jacent",
    "libelle_sous_famille_valeur",
    "type_taux",
    "type_produits_l3",
    "sens_contrat_position",
    "sens_contrat",
    "section",
    "cmgp_groupe",
    "cmgp_sous_groupe",
    "nom_societe",
    "secteur_activite",
    "nom_foret",
    "df",
    "typologie_principale",
    "libelle_pays_emetteur",
    "secteur_eco",
]

NUMERIC_MEASURES = [
    "valeur_de_marche_ctv",
    "valeur_bilan_brute_ctv",
    "pmv_latente_exteriorisables",
    "provisions_ctv",
    "pvl_mvl_ccs_hors_nomin_resid_cmgp",
    "soulte_inflation",
    "variation_indexation",
    "pvl_mvl_cmgp",
    "nominal_residuel_ctv",
    "icne_ctv",
    "valeur_boursiere_plc_ctv",
    "valeur_actuelle_ctv",
    "soulte_amortissable_initiale_ctv",
    "amortissement_soulte",
    "xx_flux_nom",
    "montant_brut_dev_val",
    "nb_titres",
    "pmvl_devise_cotation",
    "pmvl_ctv",
    "strike",
    "provisions_stock_ctv",
    "pmv_latente_ctv",
    "provisions_eoy",
    "total_encours",
]

ALL_COLUMNS = [
    "date_valorisation",
    "id_portefeuille",
    "id_valeur",
    "id_contrat_mx",
    "libelle_famille_valeur",
    "code_tiers_emetteur",
    "emetteur",
    "code_direction",
    "secteur_eco_2_lib",
    "libelle_famille",
    "secteur_eco_icb_n3_libelle",
    "secteur_eco_bic3_n3_libelle",
    "classification_portefeuille_l7",
    "code_niveau_6",
    "code_niveau_7",
    "devise_engagement",
    "cod_pays_implant",
    "valeur_de_marche_ctv",
    "valeur_bilan_brute_ctv",
    "pmv_latente_exteriorisables",
    "provisions_ctv",
    "relation_couverture",
    "type_risques_l4",
    "source",
    "reference_grappage",
    "num_lot",
    "id_valeur_sous_jacent",
    "type_ptf_cpt_french_l6",
    "libelle_sous_famille_valeur",
    "pvl_mvl_ccs_hors_nomin_resid_cmgp",
    "type_taux",
    "soulte_inflation",
    "variation_indexation",
    "pvl_mvl_cmgp",
    "type_produits_l3",
    "nominal_residuel_ctv",
    "icne_ctv",
    "valeur_boursiere_plc_ctv",
    "valeur_actuelle_ctv",
    "soulte_amortissable_initiale_ctv",
    "amortissement_soulte",
    "xx_flux_nom",
    "crs_devise_cotation_dteva10",
    "sens_contrat_position",
    "montant_brut_dev_val",
    "nb_titres",
    "pmvl_devise_cotation",
    "pmvl_ctv",
    "strike",
    "sens_contrat",
    "provisions_stock_ctv",
    "section",
    "cmgp_groupe",
    "cmgp_sous_groupe",
    "pmv_latente_ctv",
    "nom_societe",
    "secteur_activite",
    "nom_foret",
    "df",
    "typologie_principale",
    "libelle_pays_emetteur",
    "provisions_eoy",
    "secteur_eco",
    "total_encours",
    "date_insertion",
]

SCHEMA_DESCRIPTION = f"""
Table principale Impala :
- {TABLE_NAME}

Colonnes disponibles :
{", ".join(ALL_COLUMNS)}

Colonnes portefeuille importantes :
{", ".join(PORTFOLIO_COLUMNS)}

Colonnes date importantes :
{", ".join(DATE_COLUMNS)}

Colonnes de mesures numériques fréquentes :
{", ".join(NUMERIC_MEASURES)}

Règles métier et SQL :
- Moteur SQL : Impala.
- Utiliser uniquement SELECT ou WITH.
- Ne jamais inventer une colonne.
- Pour "dernier", "récent", "à date", utiliser en priorité date_valorisation sauf si l'utilisateur parle explicitement de date_insertion.
- Pour une valorisation la plus récente : date_valorisation = (SELECT MAX(date_valorisation) FROM {TABLE_NAME}).
- Si la question demande un montant total, utiliser SUM sur la mesure appropriée.
- Si la question demande une répartition, utiliser GROUP BY sur la dimension demandée.
- Si la question demande une liste de lignes détaillées, ajouter un LIMIT raisonnable.
"""

# =============================================================================
# PROMPTS
# =============================================================================

INITIAL_THINK_PROMPT = """Tu es le routeur initial d'un agent text-to-SQL.

Tu dois décider quels noeuds doivent être appelés.
Réponds uniquement en JSON valide, sans markdown.

Schéma :
{schema}

Règles de routage :
- Si la question est une salutation, une demande d'aide, ou une question évidente ne nécessitant pas la base, mets direct_answer=true.
- Si la question demande des données, agrégats, montants, expositions, encours, provisions, PMVL, portefeuille, secteur, émetteur, pays, devise, date, etc., mets direct_answer=false.
- Si la question parle de portefeuille, id_portefeuille, classification portefeuille, niveau 6, niveau 7, type portefeuille, mets needs_portfolio_search=true.
- Si la question contient des filtres métier hors date/portefeuille, mets needs_filter_extraction=true.
- Si la question contient une date, période, année, mois, "dernier", "à fin", "au", "entre", "depuis", mets needs_date_extraction=true.
- Si aucune recherche portefeuille/date/filtre n'est nécessaire mais qu'une requête SQL est nécessaire, mets needs_sql=true.

Format JSON attendu :
{{
  "direct_answer": false,
  "direct_answer_text": "",
  "needs_sql": true,
  "needs_portfolio_search": false,
  "needs_filter_extraction": false,
  "needs_date_extraction": false,
  "portfolio_terms": [],
  "filter_terms": [],
  "date_terms": [],
  "reason_short": ""
}}
"""

GET_FILTER_PROMPT = """Tu extrais les filtres métier d'une question utilisateur pour préparer une requête SQL.

Réponds uniquement en JSON valide, sans markdown.

Schéma :
{schema}

Colonnes filtrables possibles :
{filterable_columns}

Ignore les filtres portefeuille et date, car ils sont traités par des noeuds dédiés.

Format JSON attendu :
{{
  "filters": [
    {{
      "column": "nom_colonne",
      "operator": "=",
      "value": "valeur",
      "confidence": 0.0
    }}
  ],
  "notes": ""
}}
"""

GET_DATE_PROMPT = """Tu extrais les contraintes temporelles d'une question utilisateur pour préparer une requête SQL Impala.

Réponds uniquement en JSON valide, sans markdown.

Date du jour : {today}

Schéma :
{schema}

Colonnes de date possibles :
{date_columns}

Règles :
- Si l'utilisateur dit "dernier", "plus récent", "à date", privilégie date_valorisation avec MAX(date_valorisation).
- Si l'utilisateur parle explicitement d'insertion, utilise date_insertion.
- Ne fabrique pas de date si elle n'est pas déductible.

Format JSON attendu :
{{
  "date_filters": [
    {{
      "column": "date_valorisation",
      "kind": "latest | exact | between | year | month | before | after",
      "value": "",
      "start": "",
      "end": ""
    }}
  ],
  "notes": ""
}}
"""

PLAN_PROMPT = """Tu es un planificateur SQL.

Tu dois préparer un plan détaillé de requête, mais tu ne dois PAS écrire le SQL final.

Schéma :
{schema}

Contexte récent de conversation :
{conversation_context}

Question utilisateur :
{question}

Contexte portefeuille :
{portfolio_context}

Contexte filtres :
{filter_context}

Contexte dates :
{date_context}

Consignes :
- Décris l'objectif métier.
- Identifie les colonnes à sélectionner.
- Identifie les mesures à agréger.
- Identifie les filtres WHERE.
- Identifie les GROUP BY éventuels.
- Identifie l'ordre de tri éventuel.
- Si la question demande un total, utiliser SUM.
- Si la question demande une moyenne, utiliser AVG.
- Si la question demande un nombre, utiliser COUNT.
- Si la question demande une liste, sélectionner les colonnes pertinentes avec LIMIT.
- Ne pas inventer de colonne.
"""

GENERATE_SQL_PROMPT = """Tu es un générateur SQL Impala.

Réponds uniquement avec une requête SQL SELECT ou WITH.
Ne mets pas de markdown.
Ne mets pas d'explication.

Schéma :
{schema}

Contexte récent de conversation :
{conversation_context}

Question utilisateur :
{question}

Plan SQL :
{sql_plan}

Contexte portefeuille :
{portfolio_context}

Contexte filtres :
{filter_context}

Contexte dates :
{date_context}

Tentative numéro :
{attempt}

SQL précédent :
{previous_sql}

Résultat ou erreur précédente :
{previous_result}

Instruction de correction :
{fix_instruction}

Règles :
- Utilise uniquement la table {table_name}.
- Utilise uniquement des colonnes du schéma.
- Requête en lecture seule : SELECT ou WITH uniquement.
- Compatible Impala.
- Ne termine pas par un point-virgule.
- Ajoute un LIMIT raisonnable pour les listes détaillées.
- N'ajoute pas de LIMIT pour un agrégat global sauf si nécessaire.
"""

JUDGE_PROMPT = """Tu es un contrôleur qualité pour un agent text-to-SQL.

Tu dois dire si le résultat SQL répond à la question utilisateur.
Réponds uniquement en JSON valide, sans markdown.

Question utilisateur :
{question}

Plan SQL :
{sql_plan}

SQL exécuté :
{sql}

Résultat SQL :
{sql_result}

Format JSON attendu :
{{
  "is_sufficient": true,
  "reason": "",
  "fix_instruction": ""
}}

Règles :
- is_sufficient=true si le résultat permet de répondre à la question.
- is_sufficient=false si le SQL est faux, incomplet, hors sujet, ou s'il manque un filtre important.
- Si correction nécessaire, remplis fix_instruction avec une consigne claire pour régénérer le SQL.
"""

FORMULATE_PROMPT = """Tu es un assistant data analyste.

Réponds en français naturel à l'utilisateur à partir du résultat SQL.

Question utilisateur :
{question}

Plan SQL :
{sql_plan}

SQL exécuté :
{sql}

Résultat SQL :
{sql_result}

Contrôle qualité :
{judge}

Règles :
- Ne fabrique jamais de données.
- Si le résultat est vide, dis-le clairement.
- Si le résultat est tronqué, mentionne-le.
- Si le résultat contient une erreur et qu'on ne peut plus corriger, explique la limite.
- Si utile, affiche le résultat sous forme de tableau markdown.
- Termine par une courte interprétation métier.
"""

# =============================================================================
# HELPERS LLM / JSON / SQL
# =============================================================================


def _extract_json(text: str, default: dict[str, Any]) -> dict[str, Any]:
    """Extrait un objet JSON depuis une réponse LLM.

    Le modèle doit répondre en JSON pur, mais ce helper tolère un peu de bruit.
    """
    if not text:
        return dict(default)

    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else dict(default)
    except Exception:
        pass

    match = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not match:
        return dict(default)

    try:
        parsed = json.loads(match.group(0))
        return parsed if isinstance(parsed, dict) else dict(default)
    except Exception:
        return dict(default)


def _invoke_json(llm: Any, prompt: list[AnyMessage], default: dict[str, Any]) -> dict[str, Any]:
    response = llm.invoke(prompt)
    parsed = _extract_json(response.content or "", default)

    # On fusionne avec le défaut pour garantir la présence des clés attendues.
    merged = dict(default)
    merged.update(parsed)
    return merged


def _extract_sql(text: str) -> str:
    """Nettoie une réponse LLM pour récupérer uniquement le SQL."""
    if not text:
        return ""

    match = re.search(r"```(?:sql)?\s*(.*?)```", text, flags=re.IGNORECASE | re.DOTALL)
    if match:
        text = match.group(1)

    match = re.search(r"\b(select|with)\b.*", text, flags=re.IGNORECASE | re.DOTALL)
    if match:
        text = match.group(0)

    return text.strip().rstrip(";").strip()


def _strip_sql_comments(query: str) -> str:
    """Supprime les commentaires SQL simples (-- ... et /* ... */)."""
    query = re.sub(r"--.*?$", "", query, flags=re.MULTILINE)
    query = re.sub(r"/\*.*?\*/", "", query, flags=re.DOTALL)
    return query.strip()


def _strip_string_literals(query: str) -> str:
    """Remplace le contenu des littéraux de chaîne par une chaîne vide.

    Cela évite des faux positifs de validation sur des mots comme update/drop
    présents dans une valeur texte.
    """
    query = re.sub(r"'(?:[^']|'')*'", "''", query)
    query = re.sub(r'"(?:[^"]|"")*"', '""', query)
    return query


def _validate_read_only_sql(query: str) -> tuple[bool, str]:
    """Validation défensive : lecture seule, un seul statement."""
    checkable = _strip_string_literals(_strip_sql_comments(query))
    if not checkable:
        return False, "requête vide."

    without_final_semicolon = checkable[:-1].strip() if checkable.endswith(";") else checkable
    if ";" in without_final_semicolon:
        return False, "multi-statements refusés."

    lowered = without_final_semicolon.lower()
    if not re.match(r"^(select|with)\b", lowered):
        return False, "seules les requêtes SELECT ou CTE WITH sont autorisées."

    forbidden = (
        "insert",
        "update",
        "delete",
        "drop",
        "alter",
        "truncate",
        "create",
        "grant",
        "revoke",
        "merge",
        "call",
        "execute",
        "commit",
        "rollback",
        "copy",
    )
    forbidden_pattern = r"\b(" + "|".join(forbidden) + r")\b"
    if re.search(forbidden_pattern, lowered):
        return False, "mot-clé SQL non autorisé détecté."

    return True, ""


def _sql_string(value: str) -> str:
    """Quote SQL simple pour des valeurs littérales."""
    return "'" + str(value).replace("'", "''") + "'"


def _like_where(columns: list[str], terms: list[str]) -> str:
    """Construit un WHERE de recherche approximative sur plusieurs colonnes."""
    conditions: list[str] = []

    for term in terms[:5]:
        term = str(term).strip()
        if not term:
            continue

        like_value = _sql_string(f"%{term.lower()}%")

        for col in columns:
            conditions.append(f"LOWER(CAST({col} AS STRING)) LIKE {like_value}")

    return " OR ".join(conditions) if conditions else "1 = 0"


def _has_final_limit(query: str) -> bool:
    checkable = _strip_string_literals(_strip_sql_comments(query)).strip().rstrip(";").strip()
    return bool(re.search(r"\blimit\s+\d+\s*$", checkable, flags=re.IGNORECASE))


def _cap_or_add_impala_limit(query: str) -> str:
    """Ajoute ou plafonne un LIMIT final pour éviter de rapatrier trop de lignes.

    On évite le wrapping SELECT * FROM (...) car certains moteurs/versions Impala
    tolèrent mal certains WITH imbriqués.
    """
    inner = query.strip().rstrip(";").strip()

    if not _has_final_limit(inner):
        return f"{inner}\nLIMIT {MAX_ROWS + 1}"

    # Si le LLM a déjà mis un LIMIT trop grand en fin de requête, on le plafonne.
    def repl(match: re.Match[str]) -> str:
        try:
            requested = int(match.group(1))
        except Exception:
            return match.group(0)
        if requested > MAX_ROWS + 1:
            return f"LIMIT {MAX_ROWS + 1}"
        return match.group(0)

    return re.sub(r"\blimit\s+(\d+)\s*$", repl, inner, flags=re.IGNORECASE)


def _execute_sql_markdown(query: str) -> str:
    """Exécute une requête SQL en lecture seule et retourne un tableau markdown."""
    ok, reason = _validate_read_only_sql(query)
    if not ok:
        return f"Erreur : requête SQL refusée ({reason})"

    executable_sql = _cap_or_add_impala_limit(query)

    try:
        executor = SQLExecutor2(connection=SQL_CONNECTION)
        df = executor.query_to_df(executable_sql)

        if df.empty:
            return "La requête n'a retourné aucun résultat."

        truncated_msg = ""
        if len(df) > MAX_ROWS:
            df = df.head(MAX_ROWS)
            truncated_msg = f"\n\n(Résultats tronqués aux {MAX_ROWS} premières lignes.)"

        return df.to_markdown(index=False) + truncated_msg

    except Exception as exc:
        return f"Erreur SQL : {exc}"


def _last_user_question(messages: list[AnyMessage]) -> str:
    for msg in reversed(messages):
        if isinstance(msg, HumanMessage):
            return str(msg.content or "")
    return ""


def _render_recent_conversation(messages: list[AnyMessage], max_messages: int = 8) -> str:
    """Rend les derniers tours utiles pour les prompts hors historique LangChain."""
    rendered: list[str] = []

    for msg in messages[-max_messages:]:
        if isinstance(msg, HumanMessage):
            role = "Utilisateur"
        elif isinstance(msg, AIMessage):
            role = "Assistant"
        else:
            continue

        content = str(msg.content or "").strip()
        if len(content) > 2000:
            content = content[:2000] + "..."
        if content:
            rendered.append(f"{role}: {content}")

    return "\n".join(rendered)


def _selected_context_branches(route: dict[str, Any]) -> list[str]:
    branches: list[str] = []

    if route.get("needs_portfolio_search"):
        branches.append("search_portfolio")

    if route.get("needs_filter_extraction"):
        branches.append("get_filter")

    if route.get("needs_date_extraction"):
        branches.append("get_date")

    return branches


# =============================================================================
# ETAT LANGGRAPH
# =============================================================================


class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]

    question: str
    conversation_context: str

    route: dict[str, Any]
    direct_answer: str

    portfolio_context: str
    filter_context: str
    date_context: str

    sql_plan: str
    sql: str
    sql_result: str

    judge: dict[str, Any]
    attempts: int

    context_notes: Annotated[list[str], list_add]


# =============================================================================
# GRAPHE LANGGRAPH
# =============================================================================


def build_graph(llm: Any):
    """Construit le graphe de l'agent text-to-SQL."""

    def initial_think_node(state: AgentState) -> dict[str, Any]:
        default_route = {
            "direct_answer": False,
            "direct_answer_text": "",
            "needs_sql": True,
            "needs_portfolio_search": False,
            "needs_filter_extraction": False,
            "needs_date_extraction": False,
            "portfolio_terms": [],
            "filter_terms": [],
            "date_terms": [],
            "reason_short": "",
        }

        prompt = [
            SystemMessage(content=INITIAL_THINK_PROMPT.format(schema=SCHEMA_DESCRIPTION)),
        ] + state["messages"]

        route = _invoke_json(llm, prompt, default_route)

        # Normalisation défensive.
        for key in (
            "direct_answer",
            "needs_sql",
            "needs_portfolio_search",
            "needs_filter_extraction",
            "needs_date_extraction",
        ):
            route[key] = bool(route.get(key))

        for key in ("portfolio_terms", "filter_terms", "date_terms"):
            if not isinstance(route.get(key), list):
                route[key] = []

        return {
            "route": route,
            "direct_answer": str(route.get("direct_answer_text", "") or ""),
            "context_notes": [f"Routage initial : {route.get('reason_short', '')}"],
        }

    def route_after_initial(state: AgentState) -> str:
        route = state.get("route", {}) or {}

        if route.get("direct_answer"):
            return "direct_response"

        branches = _selected_context_branches(route)
        if branches:
            return "context_start"

        return "plan"

    def direct_response_node(state: AgentState) -> dict[str, Any]:
        text = state.get("direct_answer") or (
            "Je peux t'aider à transformer tes questions métier en requêtes SQL "
            "sur la table Impala décrite, puis à reformuler les résultats."
        )

        return {"messages": [AIMessage(content=text)]}

    def context_start_node(state: AgentState) -> dict[str, Any]:
        branches = _selected_context_branches(state.get("route", {}) or {})
        return {"context_notes": [f"Branches contextuelles : {', '.join(branches)}"]}

    def route_context_branches(state: AgentState) -> list[str]:
        branches = _selected_context_branches(state.get("route", {}) or {})
        return branches

    def search_portfolio_node(state: AgentState) -> dict[str, Any]:
        route = state.get("route", {}) or {}
        terms = route.get("portfolio_terms", []) or []

        if not terms:
            context = (
                "La question parle de portefeuille, mais aucun libellé ou identifiant "
                "de portefeuille précis n'a été détecté. "
                f"Colonnes portefeuille disponibles : {', '.join(PORTFOLIO_COLUMNS)}."
            )
            return {
                "portfolio_context": context,
                "context_notes": ["Contexte portefeuille sans recherche de valeur précise."],
            }

        where_clause = _like_where(PORTFOLIO_COLUMNS, [str(t) for t in terms])

        sql = f"""
SELECT DISTINCT
    {", ".join(PORTFOLIO_COLUMNS)}
FROM {TABLE_NAME}
WHERE {where_clause}
LIMIT 20
""".strip()

        result = _execute_sql_markdown(sql)

        context = f"""
Termes portefeuille détectés : {terms}

SQL de recherche portefeuille :
{sql}

Résultat de recherche portefeuille :
{result}
""".strip()

        return {
            "portfolio_context": context,
            "context_notes": ["Recherche portefeuille exécutée."],
        }

    def get_filter_node(state: AgentState) -> dict[str, Any]:
        default_filters = {
            "filters": [],
            "notes": "",
        }

        prompt = [
            SystemMessage(
                content=GET_FILTER_PROMPT.format(
                    schema=SCHEMA_DESCRIPTION,
                    filterable_columns=", ".join(FILTERABLE_COLUMNS),
                )
            )
        ] + state["messages"]

        parsed = _invoke_json(llm, prompt, default_filters)
        filters = parsed.get("filters", []) or []
        if not isinstance(filters, list):
            filters = []

        lookup_blocks: list[str] = []

        for item in filters[:6]:
            if not isinstance(item, dict):
                continue

            column = str(item.get("column", "")).strip()
            value = item.get("value")

            if column not in FILTERABLE_COLUMNS:
                continue

            if value is None or str(value).strip() == "":
                continue

            where_clause = _like_where([column], [str(value)])

            lookup_sql = f"""
SELECT DISTINCT
    {column}
FROM {TABLE_NAME}
WHERE {where_clause}
LIMIT 20
""".strip()

            lookup_result = _execute_sql_markdown(lookup_sql)

            lookup_blocks.append(
                f"""
Filtre candidat :
- colonne : {column}
- opérateur : {item.get("operator", "=")}
- valeur demandée : {value}
- confiance : {item.get("confidence", "")}

Valeurs proches trouvées :
{lookup_result}
""".strip()
            )

        context = f"""
Filtres extraits :
{json.dumps(filters, ensure_ascii=False, indent=2)}

Notes :
{parsed.get("notes", "")}

Vérification de valeurs :
{chr(10).join(lookup_blocks) if lookup_blocks else "Aucune vérification de valeur exécutée."}
""".strip()

        return {
            "filter_context": context,
            "context_notes": ["Extraction des filtres métier effectuée."],
        }

    def get_date_node(state: AgentState) -> dict[str, Any]:
        default_dates = {
            "date_filters": [],
            "notes": "",
        }

        prompt = [
            SystemMessage(
                content=GET_DATE_PROMPT.format(
                    schema=SCHEMA_DESCRIPTION,
                    today=date.today().isoformat(),
                    date_columns=", ".join(DATE_COLUMNS),
                )
            )
        ] + state["messages"]

        parsed = _invoke_json(llm, prompt, default_dates)
        date_filters = parsed.get("date_filters", []) or []
        if not isinstance(date_filters, list):
            date_filters = []

        latest_blocks: list[str] = []
        latest_columns = {
            str(item.get("column", "")).strip()
            for item in date_filters
            if isinstance(item, dict) and str(item.get("kind", "")).strip().lower() == "latest"
        }

        for col in latest_columns:
            if col not in DATE_COLUMNS:
                continue

            latest_sql = f"SELECT MAX({col}) AS max_{col} FROM {TABLE_NAME}"
            latest_result = _execute_sql_markdown(latest_sql)
            latest_blocks.append(
                f"Dernière valeur disponible pour {col} :\n{latest_result}"
            )

        context = f"""
Contraintes de date extraites :
{json.dumps(date_filters, ensure_ascii=False, indent=2)}

Notes :
{parsed.get("notes", "")}

Contrôles de dates disponibles :
{chr(10).join(latest_blocks) if latest_blocks else "Aucun contrôle de date exécuté."}
""".strip()

        return {
            "date_context": context,
            "context_notes": ["Extraction des contraintes de date effectuée."],
        }

    def plan_node(state: AgentState) -> dict[str, Any]:
        prompt = [
            SystemMessage(
                content=PLAN_PROMPT.format(
                    schema=SCHEMA_DESCRIPTION,
                    conversation_context=state.get("conversation_context", ""),
                    question=state.get("question", ""),
                    portfolio_context=state.get("portfolio_context", ""),
                    filter_context=state.get("filter_context", ""),
                    date_context=state.get("date_context", ""),
                )
            )
        ]

        response = llm.invoke(prompt)

        return {
            "sql_plan": response.content or "",
            "context_notes": ["Plan SQL produit."],
        }

    def generate_sql_node(state: AgentState) -> dict[str, Any]:
        attempt = state.get("attempts", 0) + 1
        judge = state.get("judge", {}) or {}

        prompt = [
            SystemMessage(
                content=GENERATE_SQL_PROMPT.format(
                    schema=SCHEMA_DESCRIPTION,
                    conversation_context=state.get("conversation_context", ""),
                    question=state.get("question", ""),
                    sql_plan=state.get("sql_plan", ""),
                    portfolio_context=state.get("portfolio_context", ""),
                    filter_context=state.get("filter_context", ""),
                    date_context=state.get("date_context", ""),
                    attempt=attempt,
                    previous_sql=state.get("sql", ""),
                    previous_result=state.get("sql_result", ""),
                    fix_instruction=judge.get("fix_instruction", ""),
                    table_name=TABLE_NAME,
                )
            )
        ]

        response = llm.invoke(prompt)
        sql = _extract_sql(response.content or "")

        return {
            "sql": sql,
            "attempts": attempt,
            "context_notes": [f"SQL généré, tentative {attempt}."],
        }

    def execute_sql_node(state: AgentState) -> dict[str, Any]:
        sql = state.get("sql", "")

        if not sql:
            result = "Erreur : aucune requête SQL générée."
        else:
            result = _execute_sql_markdown(sql)

        return {
            "sql_result": result,
            "context_notes": ["SQL exécuté."],
        }

    def judge_result_node(state: AgentState) -> dict[str, Any]:
        sql_result = state.get("sql_result", "")

        if sql_result.startswith("Erreur"):
            judge = {
                "is_sufficient": False,
                "reason": "Erreur SQL détectée.",
                "fix_instruction": sql_result[:2000],
            }
            return {
                "judge": judge,
                "context_notes": ["Résultat SQL jugé insuffisant à cause d'une erreur."],
            }

        default_judge = {
            "is_sufficient": True,
            "reason": "",
            "fix_instruction": "",
        }

        prompt = [
            SystemMessage(
                content=JUDGE_PROMPT.format(
                    question=state.get("question", ""),
                    sql_plan=state.get("sql_plan", ""),
                    sql=state.get("sql", ""),
                    sql_result=state.get("sql_result", ""),
                )
            )
        ]

        judge = _invoke_json(llm, prompt, default_judge)
        judge["is_sufficient"] = bool(judge.get("is_sufficient"))

        return {
            "judge": judge,
            "context_notes": [f"Contrôle qualité : {judge.get('reason', '')}"],
        }

    def route_after_judge(state: AgentState) -> str:
        judge = state.get("judge", {}) or {}

        if judge.get("is_sufficient"):
            return "formulate_answer"

        if state.get("attempts", 0) >= MAX_SQL_ATTEMPTS:
            return "formulate_answer"

        return "generate_sql"

    def formulate_answer_node(state: AgentState) -> dict[str, Any]:
        prompt = [
            SystemMessage(
                content=FORMULATE_PROMPT.format(
                    question=state.get("question", ""),
                    sql_plan=state.get("sql_plan", ""),
                    sql=state.get("sql", ""),
                    sql_result=state.get("sql_result", ""),
                    judge=json.dumps(state.get("judge", {}), ensure_ascii=False, indent=2),
                )
            )
        ]

        response = llm.invoke(prompt)
        text = response.content or "Je n'ai pas pu produire de réponse exploitable."

        return {"messages": [AIMessage(content=text)]}

    builder = StateGraph(AgentState)

    builder.add_node("initial_think", initial_think_node)
    builder.add_node("direct_response", direct_response_node)
    builder.add_node("context_start", context_start_node)

    builder.add_node("search_portfolio", search_portfolio_node)
    builder.add_node("get_filter", get_filter_node)
    builder.add_node("get_date", get_date_node)

    builder.add_node("plan", plan_node)
    builder.add_node("generate_sql", generate_sql_node)
    builder.add_node("execute_sql", execute_sql_node)
    builder.add_node("judge_result", judge_result_node)
    builder.add_node("formulate_answer", formulate_answer_node)

    builder.add_edge(START, "initial_think")

    builder.add_conditional_edges(
        "initial_think",
        route_after_initial,
        {
            "direct_response": "direct_response",
            "context_start": "context_start",
            "plan": "plan",
        },
    )

    builder.add_edge("direct_response", END)

    # Fan-out parallèle puis jonction sur plan.
    # `then="plan"` fait office de barrière : le noeud plan attend la fin des
    # branches sélectionnées par route_context_branches.
    builder.add_conditional_edges(
        "context_start",
        route_context_branches,
        {
            "search_portfolio": "search_portfolio",
            "get_filter": "get_filter",
            "get_date": "get_date",
        },
        then="plan",
    )

    builder.add_edge("plan", "generate_sql")
    builder.add_edge("generate_sql", "execute_sql")
    builder.add_edge("execute_sql", "judge_result")

    builder.add_conditional_edges(
        "judge_result",
        route_after_judge,
        {
            "generate_sql": "generate_sql",
            "formulate_answer": "formulate_answer",
        },
    )

    builder.add_edge("formulate_answer", END)

    return builder.compile()


# =============================================================================
# CODE AGENT DATAIKU
# =============================================================================


class MyLLM(BaseLLM):
    def __init__(self):
        client = dataiku.api_client()
        project = client.get_default_project()

        dku_llm = project.get_llm(LLM_ID)
        base_llm = dku_llm.as_langchain_chat_model()

        # Température basse recommandée pour du SQL reproductible.
        # On n'utilise pas bind_tools : les actions sont des noeuds explicites.
        self.llm = base_llm.bind(temperature=TEMPERATURE)

        self.graph = build_graph(self.llm)

    @staticmethod
    def _to_langchain_messages(query: dict[str, Any]) -> list[AnyMessage]:
        """Convertit les messages Dataiku LLM Mesh vers LangChain.

        On garde seulement user/assistant pour éviter qu'un message externe
        injecte un SystemMessage non maîtrisé dans le graphe.
        """
        lc_messages: list[AnyMessage] = []

        for msg in query.get("messages", []):
            role = msg.get("role")
            content = msg.get("content", "")

            if role == "user":
                lc_messages.append(HumanMessage(content=content))
            elif role == "assistant":
                lc_messages.append(AIMessage(content=content))

        return lc_messages

    def _initial_state(self, query: dict[str, Any]) -> AgentState:
        messages = self._to_langchain_messages(query)
        question = _last_user_question(messages)

        return {
            "messages": messages,
            "question": question,
            "conversation_context": _render_recent_conversation(messages),
            "route": {},
            "direct_answer": "",
            "portfolio_context": "",
            "filter_context": "",
            "date_context": "",
            "sql_plan": "",
            "sql": "",
            "sql_result": "",
            "judge": {},
            "attempts": 0,
            "context_notes": [],
        }

    @staticmethod
    def _final_text_from_state(final_state: dict[str, Any]) -> str:
        messages = final_state.get("messages", []) or []

        for msg in reversed(messages):
            if isinstance(msg, AIMessage) and msg.content:
                return str(msg.content)

        return (
            "Je n'ai pas pu produire de réponse finale exploitable. "
            "Vérifie les logs de l'agent, les droits SQL et la configuration LLM."
        )

    # -------------------------------------------------------------------------
    # Mode non-streaming
    # -------------------------------------------------------------------------
    def process(self, query, settings, trace):
        state = self._initial_state(query)

        try:
            final_state = self.graph.invoke(state)
        except Exception as exc:
            return {
                "text": (
                    "Une erreur est survenue pendant le traitement de l'agent. "
                    f"Détail technique : {exc}"
                )
            }

        return {"text": self._final_text_from_state(final_state)}

    # -------------------------------------------------------------------------
    # Mode streaming
    # -------------------------------------------------------------------------
    def process_stream(self, query, settings, trace):
        state = self._initial_state(query)
        final_text = ""

        node_labels = {
            "initial_think": "Analyse de la question",
            "context_start": "Préparation du contexte",
            "search_portfolio": "Recherche portefeuille",
            "get_filter": "Extraction des filtres",
            "get_date": "Extraction des dates",
            "plan": "Planification SQL",
            "generate_sql": "Génération SQL",
            "execute_sql": "Exécution SQL",
            "judge_result": "Contrôle qualité",
            "formulate_answer": "Reformulation finale",
            "direct_response": "Réponse directe",
        }

        try:
            for event in self.graph.stream(state, stream_mode="updates"):
                for node, update in event.items():
                    if STREAM_PROGRESS and node in node_labels and node not in (
                        "formulate_answer",
                        "direct_response",
                    ):
                        yield {"chunk": {"text": f"\n\n> {node_labels[node]}..."}}

                    if node in ("direct_response", "formulate_answer"):
                        messages = update.get("messages", []) if isinstance(update, dict) else []
                        if messages:
                            last = messages[-1]
                            if isinstance(last, AIMessage) and last.content:
                                final_text = str(last.content)

            if final_text:
                yield {"chunk": {"text": f"\n\n---\n\n**Réponse**\n\n{final_text}"}}
            else:
                yield {
                    "chunk": {
                        "text": (
                            "\n\nJe n'ai pas pu produire de réponse finale exploitable. "
                            "Vérifie les logs de l'agent, les droits SQL et la configuration LLM."
                        )
                    }
                }

        except Exception as exc:
            yield {
                "chunk": {
                    "text": (
                        "\n\nUne erreur est survenue pendant le traitement de l'agent. "
                        f"Détail technique : {exc}"
                    )
                }
            }
