# Agent Text-to-SQL Impala Dataiku + LangGraph + Mistral Small 3.2

Ce ZIP contient un agent Dataiku Code Agent complet avec une architecture LangGraph explicite :

```text
START
  -> initial_think
      -> direct_response si la réponse est évidente
      -> sinon context_start
            -> search_portfolio en parallèle si besoin
            -> get_filter en parallèle si besoin
            -> get_date en parallèle si besoin
      -> plan
      -> generate_sql
      -> execute_sql
      -> judge_result
            -> generate_sql si correction nécessaire
            -> formulate_answer si OK ou limite atteinte
END
```

## Fichier principal

- `agent_text_to_sql_impala_langgraph.py`

## À modifier avant utilisation

Dans le fichier Python, adapte ces constantes :

```python
LLM_ID = "mistral:votre-connexion:mistral-small-2506"
SQL_CONNECTION = "votre_connexion_sql"
TABLE_NAME = "votre_table_impala"
```

Exemple :

```python
LLM_ID = "mistral:llm-mistral:mistral-small-2506"
SQL_CONNECTION = "impala_prod"
TABLE_NAME = "db_finance.valorisation_portefeuille"
```

## Dépendances Code Env Dataiku

Les dépendances exactes dépendent de ta version Dataiku, mais il faut notamment :

```text
langgraph
langchain-core
tabulate
```

`tabulate` est utilisé par `pandas.DataFrame.to_markdown()`.

## Pourquoi cette architecture est plus robuste avec Mistral

Cette version n'utilise pas de `tool_calls` LangChain pour exécuter SQL.

Le LLM produit seulement :

1. du JSON de routage ;
2. du JSON de filtres/dates ;
3. un plan SQL ;
4. une requête SQL ;
5. une reformulation finale.

Les actions concrètes, notamment la recherche portefeuille et l'exécution SQL, sont faites par des noeuds LangGraph Python explicites. Cela évite les erreurs Mistral de type :

```text
assistant message with tool_calls must be followed by tool messages
```

## Notes Impala

La fonction `_execute_sql_markdown()` ajoute ou plafonne un `LIMIT` final pour éviter de rapatrier trop de lignes.

La validation SQL autorise uniquement :

- `SELECT`
- `WITH`

Elle refuse notamment :

- `INSERT`
- `UPDATE`
- `DELETE`
- `DROP`
- `ALTER`
- `CREATE`
- multi-statements

## Personnalisation recommandée

Tu peux enrichir :

- `SCHEMA_DESCRIPTION` avec des règles métier propres à ton projet ;
- `PORTFOLIO_COLUMNS` si d'autres colonnes identifient un portefeuille ;
- `FILTERABLE_COLUMNS` si tu veux autoriser plus ou moins de filtres ;
- `NUMERIC_MEASURES` si tu veux mieux guider les agrégations.
